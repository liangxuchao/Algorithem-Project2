package examples.visualization;

public class BFSResult {
    public int Rank;
    public int Target;
}
